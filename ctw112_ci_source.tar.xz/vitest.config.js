import { cloudflareTest } from '@cloudflare/vitest-pool-workers';
import { defineConfig } from 'vitest/config';

// Synthetic TEST-ONLY 32-byte base64url master key injected only into the
// Workers-runtime test isolate. Production Wrangler still requires a real secret.
const TEST_BYOK_MASTER_KEY = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA';

export default defineConfig({
  plugins:[cloudflareTest({
    wrangler:{configPath:'./tests/worker/wrangler.test.jsonc'},
    miniflare:{bindings:{BYOK_SESSION_MASTER_KEY_CURRENT:TEST_BYOK_MASTER_KEY}}
  })],
  test:{include:['tests/worker/**/*.test.js'],testTimeout:20000}
});
