# Mutation Test Report — Cosmic Transcriber Web 1.0.12

Final audit-source result: **224/224 deliberate safeguard removals detected**.

The mutation suite does not claim mathematical completeness. Its purpose is to prove that important release/security/correctness assertions actually fail when corresponding protections are deliberately removed or weakened.

Coverage includes Access JWT claims, BYOK cookie/AAD/rotation, fixed OpenAI upstream and server-owned Authorization, redirect blocking, model/request limits, origin/CSP/CORS/DOM boundaries, source/chunk hashes, checkpoint schema/principal/billing semantics, MP3/ID3/VBR behavior, queue/output/resource limits, Unicode/bidi safety, Worker/MSW lifecycle, browser isolation, dependency/install-script policy, PowerShell/release certification, canonical UTF-8 packaging, exact provenance, asset rebuild/inspection and Wrangler strict mode.

New 1.0.12 mutations specifically prove detection of:

- disabling PowerShell cmdlet named-parameter validation;
- removing the guided runner's named-parameter preflight;
- reintroducing deployed or Worker/integration/E2E runtime-test `APP_VERSION` drift;
- removing the mandatory version-consistency release gate;
- the exact invalid `New-Item -LiteralPath` class through validator self-test coverage;
- regressing the paste-once launcher to invalid `New-Item -LiteralPath`;
- regressing the paste-once launcher to a reusable/non-unique work directory;
- drifting `.nvmrc` or the private Windows Node version;
- weakening the official Node archive SHA-256 pin or removing download hash enforcement;
- putting machine Node ahead of the private toolchain on PATH;
- removing the private npm prefix;
- reintroducing machine-wide winget Node mutation;
- removing the exact private npm PowerShell binding;
- making the binding call ambient `npm` instead of the verified private CLI;
- skipping absolute private npm CLI verification.

The prior direct-Worker/MSW mock-hit, certification-failure, install-script, keyring, fresh-deploy-copy and provenance mutations remain active.
