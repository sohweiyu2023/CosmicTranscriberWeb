# Known Limitations

- V1 accepts MP3 only to preserve the mature desktop parser/chunker scope.
- Active jobs require the tab to remain open; there is no durable background Worker job.
- After browser restart the user must reselect the original source file; raw audio is not checkpointed.
- Stateless BYOK cookie deletion does not retroactively revoke stolen copies; revoke OpenAI key on suspected compromise.
- No global speaker identity mapping across independently diarized parts.
- Current OpenAI diarization supports optional known-speaker reference clips (up to four speakers), but V1 does not collect/upload those extra reference recordings; automatic part-scoped speaker labels remain the supported Cosmic workflow.
- No server-side cross-tab/device at-most-once coordinator in V1; the UI blocks duplicate start in one tab, but two separate tabs/devices can intentionally submit the same paid work. A small Durable Object can be evaluated later if field evidence warrants it.
- Cost is a dated estimate, not an invoice guarantee. The diarization per-minute display is explicitly derived/approximate because OpenAI currently publishes its audio-token rates but not a direct diarization per-minute estimate.
- Current WebKit automation cannot substitute for branded Safari.
- This audit-candidate ZIP lacks the exact final `package-lock.json` because the editable upload did not include it and the audit sandbox could not fetch the complete public-registry graph. Production release is blocked until a clean connected Windows machine generates/reviews the lock and passes `npm ci`/audit/Worker/integration/browser suites.
- IndexedDB checkpoints are scoped to a pseudonymous verified Access principal, but they still live inside the local browser profile. A malicious local browser-profile administrator/extension remains outside the app's trust boundary.
