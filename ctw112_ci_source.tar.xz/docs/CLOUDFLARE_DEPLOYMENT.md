# Cloudflare Deployment — Cosmic Transcriber Web 1.0.12

This guide continues from the owner's actual state on 2026-08-09. It intentionally does **not** ask you to redo completed setup.

Current state:
- `awakeningtoreality.com` is already an active Cloudflare zone.
- staging hostname is `transcriber-staging.awakeningtoreality.com`.
- production hostname is `transcriber.awakeningtoreality.com`.
- the existing Zero Trust organization is **citeledger**, used by unrelated accounting software. Do not rename it or alter its unrelated Access application/settings.
- global identity providers already include One-time PIN and Google. Do not remove either.
- a staging Access application for `transcriber-staging.awakeningtoreality.com` already exists with a tester-email Allow policy/OTP; staging AUD and Access team domain were copied locally.
- no Cosmic staging/production Worker has been deployed, no real Cosmic BYOK master secret has been uploaded, and no production Cosmic Access application exists yet.

**Never deploy the assistant-provided audit-candidate ZIP.** It contains `releaseReady:false` and deployment verification rejects it. First produce a Windows-certified ZIP, then deploy from a fresh extraction of that certified ZIP.

---

## Part A — certify and guide the first deployment from one real PowerShell process

### A1. Extract the audit candidate

Put `CosmicTranscriberWeb-1.0.12-audited-source-candidate.zip` in your normal Downloads folder. The recommended operator path is the version-specific paste-once launcher supplied with this release: it finds that ZIP, extracts a fresh unique run directory, and invokes the shipped guided runner. Do not `cd` into the `.zip` path and do not reuse launcher text from an older version.

### A2. Use the exact version-specific paste-once block supplied with the release

The paste-once block auto-finds the ZIP in Downloads, extracts a unique run tree and invokes the shipped `FIRST-DEPLOY-WINDOWS.ps1`. If you intentionally extract the ZIP yourself instead, the direct fallback command from the extracted project folder is `pwsh -NoProfile -ExecutionPolicy Bypass -File .\FIRST-DEPLOY-WINDOWS.ps1`.

Do **not** paste old multi-stage command blocks from earlier versions. `PASTE-ONCE-WINDOWS.ps1` is version-bound, extracts a unique run tree, then hands control to the shipped one-process guided runner, which exits immediately on a failed native/release/deployment gate.

The guided runner does not install, upgrade or trust machine-wide Node/npm. It downloads the reviewed official portable Node 24.19.0 archive for Windows x64/ARM64, verifies the published SHA-256 before extraction, installs exact npm 12.0.2 into a private per-user prefix, prepends those binaries for the release process tree, and leaves global Node installations untouched. It then invokes `RELEASE-WINDOWS.ps1`, which performs the full dependency refresh/install-script review, npm audit, clean install, Worker/integration/browser gates, build inspection, isolated release packaging, fresh ZIP extraction, repeated release verification, `releaseReady:true` check and pristine deployment-copy creation. The guided runner will not configure Access or open Wrangler login unless certification really succeeds.

Success of the certification stage contains:

```text
=== ALL LOCAL RELEASE GATES PASSED ===
```

Any certification failure contains:

```text
=== RELEASE CERTIFICATION FAILED - DO NOT DEPLOY ===
```

and the outer guided runner ends with:

```text
=== STOPPED — DO NOT CONTINUE TO A LATER STAGE ===
```

At that point send the full output for review; do not manually jump to a later command.

### A4. Identify the only deployable ZIP

The certified file should be:

```text
CosmicTranscriberWeb-1.0.12-source.zip
```

Its internal `RELEASE_MANIFEST.json` must contain:

```json
"releaseReady": true
```

The original `...audited-source-candidate.zip` remains intentionally undeployable.

---

## Part B — use the pristine deployment copy created automatically

### B1. Do not invent or pre-create the deploy path

A successful 1.0.12 certification now extracts the certified ZIP for you. Near the end of the green success output, copy the exact line after:

```text
Prepared deployment folder: ...
```

Then use the exact command printed immediately below it. For example, if the script printed:

```text
Prepared deployment folder: C:\Users\cyber\Downloads\deploy\CosmicTranscriberWeb-1.0.12
```

run:

```powershell
Set-Location 'C:\Users\cyber\Downloads\deploy\CosmicTranscriberWeb-1.0.12'
npm ci
```

Do **not** guess `C:\Users\cyber\Downloads\deploy\...` before certification succeeds. Your 1.0.5 transcript showed exactly why: when the release gate stops first, no certified ZIP/deploy copy exists, and continuing in the candidate leads to missing-lock and missing-Wrangler cascades.

Do not copy `node_modules`, `dist`, test-results or old local files from the development tree.

### B2. Understand the provenance lock

After certification, deployment permits changes only to these four private Wrangler fields:

- `env.staging.vars.ACCESS_TEAM_DOMAIN`
- `env.staging.vars.ACCESS_AUDIENCE`
- `env.production.vars.ACCESS_TEAM_DOMAIN`
- `env.production.vars.ACCESS_AUDIENCE`

Every other certified source file must still be present with its certified checksum. **Extra unlisted source files are also rejected.** Generated directories such as `node_modules` and `dist` are excluded from source provenance.

If you need to change code, routes, origins, rate-limit IDs, `workers_dev`, Preview URLs, compatibility date, logging, secret names, package files or any other Wrangler security/configuration field, change the development source and create a new certified ZIP. Do not patch the certified deployment copy.

## Part C — staging Access verification (already mostly done)

### C1. Open the existing application

1. Sign in to Cloudflare Dashboard.
2. In the left navigation choose **Zero Trust**.
3. In Zero Trust choose **Access controls** → **Applications**.
4. Find the existing Cosmic staging application (`transcriber-staging`) and open **Configure**.
5. Confirm the application hostname is exactly:

```text
transcriber-staging.awakeningtoreality.com
```

6. Confirm the intended tester email address(es) are in an **Allow** policy.
7. Confirm One-time PIN remains an available login method for the application/testers.
8. Do **not** alter the unrelated CiteLedger application.
9. Do **not** remove Google or OTP globally.

OTP must remain restricted by a specific email/email-list policy; do not create an unrestricted OTP Allow rule.

### C2. Re-copy staging AUD only if necessary

Inside the staging Access application, use its configuration/additional-settings view to locate the **Application Audience (AUD) Tag** and copy it locally. You do not need to paste it into ChatGPT.

Your Access team domain has the form:

```text
https://<your-team>.cloudflareaccess.com
```

If you need to locate it again: Cloudflare Dashboard → **Zero Trust** → **Settings** → **Team name and domain**. Copy the team domain shown there and prefix it with `https://` when the helper asks for it. Do **not** rename the team domain; the existing Zero Trust organization is shared with unrelated software.

---

## Part D — configure the two private staging Access values safely

Stay in the **prepared deployment folder printed by certification** and run:

```powershell
npm run configure:access:staging
```

The helper asks for exactly two values:
1. the staging Access team-domain origin, such as `https://your-team.cloudflareaccess.com`;
2. the staging application's exact **Application Audience (AUD) Tag**.

It refuses audit-candidate (`releaseReady:false`) trees, normalizes/validates the team domain, changes only `env.staging.vars.ACCESS_TEAM_DOMAIN` and `env.staging.vars.ACCESS_AUDIENCE`, rechecks the certified source/Wrangler fingerprint, and restores the original file if the resulting deployment configuration is invalid.

You do **not** need to hand-edit `wrangler.jsonc`. Do not put an OpenAI API key or BYOK encryption key into plaintext Wrangler vars.

Then run:

```powershell
node scripts/deploy-verify.mjs staging
```

Success must say:

```text
Deployment configuration verified for staging.
```

If it says `DEPLOY BLOCKED`, stop. Do not disable the verifier.

## Part E — rate-limit namespace sanity check

Current 1.0.12 staging IDs are:

```text
RL_KEY_SESSION  1865743469
RL_KEY_TEST     1935541582
RL_TRANSCRIBE   1942507375
```

Production uses separate IDs already present in `wrangler.jsonc`.

Cloudflare's Rate Limiting binding treats identical `namespace_id` values as shared counters. If you discover one of these IDs is already used by another Worker in your account, do **not** change CiteLedger and do **not** patch the certified deployment copy. Change the Cosmic development source, recertify a new ZIP, and use that new ZIP.

---

## Part F — authenticate the installed Wrangler CLI

From the certified deployment directory run:

```powershell
node scripts/wrangler-invoke.mjs login --use-keyring
node scripts/wrangler-invoke.mjs whoami
```

The first command opens Cloudflare's browser authorization flow. Approve it. `--use-keyring` opts Wrangler into encrypted OAuth storage with the key held in **Windows Credential Manager**.

`whoami` must identify the Cloudflare account containing `awakeningtoreality.com` **and should report keyring/encrypted credential storage**. If it is the wrong account, stop.

---

## Part G — first staging deployment

Only do this when you deliberately want to create/update the external staging Worker.

Run:

```powershell
npm run deploy:first:staging
```

Immediately before Wrangler runs, 1.0.12:
- rechecks release provenance/configuration;
- rebuilds `dist/public` from certified source;
- inspects the built frontend for release/security problems;
- generates a fresh random 32-byte **staging-only** `BYOK_SESSION_MASTER_KEY_CURRENT`;
- stores the temporary secret file outside the project;
- deploys with installed Wrangler using `--strict --env staging --secrets-file ...`;
- deletes the temporary secret file in `finally`.

The secret value is not printed.

After success run:

```powershell
node scripts/wrangler-invoke.mjs secret list --env staging
node scripts/wrangler-invoke.mjs deployments list --env staging
```

The secret list should show the name:

```text
BYOK_SESSION_MASTER_KEY_CURRENT
```

but not its value. Record the deployment/version ID shown by the deployments command.

Future staging code deployments use:

```powershell
npm run deploy:staging
```

That command also re-verifies provenance, rebuilds and inspects assets, and deploys with `--strict`.

---

## Part H — verify staging Custom Domain, DNS, TLS and exposure

### H1. Worker domain

1. In Cloudflare Dashboard go to **Workers & Pages**.
2. In **Overview**, select `cosmic-transcriber-web-staging`.
3. Open **Settings** → **Domains & Routes**.
4. Confirm the Custom Domain is exactly:

```text
transcriber-staging.awakeningtoreality.com
```

Wrangler's `custom_domain:true` configuration should create/manage the DNS record and certificate automatically. Do not add a second arbitrary CNAME first.

### H2. workers.dev

On the same **Domains & Routes** page, confirm the `workers.dev` route is disabled. The project sets `workers_dev:false`; if the dashboard disagrees after deployment, stop and investigate rather than enabling it.

### H3. Preview URLs

Still under **Settings** → **Domains & Routes**, find **Preview URLs** and confirm they are **Disabled**. The source also sets `preview_urls:false`.

### H4. DNS/TLS

Open the `awakeningtoreality.com` zone → **DNS** → **Records** and confirm Cloudflare created/associated the staging Worker Custom Domain record. Then visit:

```text
https://transcriber-staging.awakeningtoreality.com
```

The browser must show valid HTTPS/TLS.

---

## Part I — test Access before entering an OpenAI key

1. Open a new Incognito/InPrivate browser.
2. Visit `https://transcriber-staging.awakeningtoreality.com`.
3. You should see Cloudflare Access **before** Cosmic Transcriber.
4. Enter an explicitly allowed tester email and select **Send login code**.
5. Enter the OTP received by email.
6. Cosmic Transcriber should load after successful authentication.
7. In a second fresh private session, try an email not covered by the Allow policy. It must not reach the application. Cloudflare may still display a generic “code sent” style message to avoid email enumeration; an unauthorized address must not successfully authenticate.

If the app shell is reachable without Access, stop before entering any OpenAI key.

---

## Part J — verify Mode-B BYOK security in staging

Use a tester-owned OpenAI key only.

1. In Cosmic Transcriber choose **Configure API key**.
2. Paste the key into the password-style field.
3. Save the secure session.
4. The plaintext field must clear.
5. In browser DevTools → **Application**, inspect Local Storage, Session Storage, IndexedDB, Cache Storage and Cookies.
6. The raw OpenAI key must not appear anywhere in JS-readable storage.
7. The `__Host-cosmic_byok` cookie should be HttpOnly; page JavaScript must not be able to read it.
8. In DevTools → **Network**, inspect application requests. The browser must not be allowed to substitute an attacker-controlled OpenAI Authorization credential; the Worker constructs upstream Authorization from the encrypted BYOK session.

Do not put a deployment-owner OpenAI key into Cloudflare Secrets or Wrangler config. Cosmic is Mode B only.

---

## Part K — optional tiny live OpenAI acceptance test

Only after all local/mock/staging checks are green and only if you accept the small OpenAI charge:

1. Use one short, non-sensitive MP3.
2. Keep retry settings conservative/default.
3. Test ordinary completed-file transcription first.
4. Verify TXT/Markdown downloads, Unicode filenames, file picker, drag/drop, progress and cancellation.
5. If desired, use a short two-speaker file for diarization.
6. Treat speaker identities as part-scoped across independently uploaded chunks; never assume `Part 1 Speaker A` equals `Part 2 Speaker A` without evidence.

No live OpenAI test is required to create the source artifact, but it is a useful staging acceptance gate before production.

---

## Part L — inspect staging resource behavior

In Cloudflare Dashboard:

1. **Workers & Pages** → `cosmic-transcriber-web-staging`.
2. Open **Observability/Metrics** (wording can vary slightly).
3. Review representative transcription requests for runtime errors, CPU time/duration and other resource-limit symptoms.

Worker-first authentication deliberately causes app/static requests to execute Worker code before asset serving. Do not assume a Free plan is sufficient for representative transcription traffic solely because a tiny smoke test works.

---

## Part M — create the production Access application only after staging acceptance

Do not touch the existing CiteLedger application. Current Cloudflare Access UI steps are:

1. Cloudflare Dashboard → **Zero Trust**.
2. **Access controls** → **Applications**.
3. Select **Create new application**.
4. Select **Self-hosted and private**.
5. Select **Add public hostname**.
6. In **Domain**, select `awakeningtoreality.com`; enter the subdomain `transcriber` so the complete public hostname is exactly `transcriber.awakeningtoreality.com`.
7. Under **Access policies**, create/select an **Allow** policy limited to the intended production email address(es) or other explicit identities. Access is deny-by-default outside matching Allow policies.
8. Under the application's identity-provider choices, keep the intended existing providers available. Do not remove Google or One-time PIN globally. If using OTP, the Allow policy must still restrict the permitted identities; do not use an unrestricted OTP condition as authorization.
9. Choose an appropriate session duration and save the application.
10. Open the new application → **Configure** → **Additional settings** and copy its **Application Audience (AUD) Tag** locally. Do not paste it into ChatGPT.

## Part N — configure only production private Access values

In the same certified prepared deployment copy run:

```powershell
npm run configure:access:production
```

Paste the same exact Access team-domain origin and the **production** application's AUD when prompted. The helper is provenance-safe and changes only the two permitted production fields.

Then run:

```powershell
node scripts/deploy-verify.mjs production
```

Continue only if it says:

```text
Deployment configuration verified for production.
```

## Part O — first production deployment

Only after staging is accepted and you intentionally choose to go live:

```powershell
npm run deploy:first:production
```

This generates a **different production BYOK master key**, rebuilds/inspects certified assets, and deploys with Wrangler `--strict`.

Then:

```powershell
node scripts/wrangler-invoke.mjs secret list --env production
node scripts/wrangler-invoke.mjs deployments list --env production
```

Record the production deployment/version ID. Repeat all domain/TLS/Access/BYOK/exposure/smoke checks at:

```text
https://transcriber.awakeningtoreality.com
```

Future production code deployment:

```powershell
npm run deploy:production
```

---

## Part P — rollback

### Dashboard rollback

1. Cloudflare Dashboard → **Workers & Pages**.
2. Select the relevant Cosmic Worker.
3. Open **Deployments**.
4. Locate the known-good deployment/version.
5. Use its rollback action/menu and verify the target version before confirming.

### CLI rollback

First list deployments:

```powershell
node scripts/wrangler-invoke.mjs deployments list --env staging
```

Then roll back deliberately to the known-good ID:

```powershell
node scripts/wrangler-invoke.mjs rollback <KNOWN_GOOD_VERSION_ID> --env staging
```

Production equivalent:

```powershell
node scripts/wrangler-invoke.mjs deployments list --env production
node scripts/wrangler-invoke.mjs rollback <KNOWN_GOOD_VERSION_ID> --env production
```

Do not guess a version ID.

---

## Part Q — real Safari final gate

After Windows Chrome/Edge and Playwright Chromium/Firefox/WebKit/Mobile Safari-emulation pass, perform the short checklist in `SAFARI_MAC_ACCEPTANCE.md` on a real Mac. A Playwright WebKit PASS is **not** branded Safari certification.

---

## Official references rechecked 2026-08-09

- Cloudflare Workers Custom Domains: https://developers.cloudflare.com/workers/configuration/routing/custom-domains/
- Workers `workers.dev`: https://developers.cloudflare.com/workers/configuration/routing/workers-dev/
- Preview URLs: https://developers.cloudflare.com/workers/versions-and-deployments/preview-urls/
- Workers static asset routing / worker-first authentication: https://developers.cloudflare.com/workers/static-assets/routing/single-page-application/
- Wrangler configuration/secrets: https://developers.cloudflare.com/workers/wrangler/configuration/
- Cloudflare Access self-hosted public apps: https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/self-hosted-public-app/
- Cloudflare Access JWT/AUD validation: https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/validating-json/
- Wrangler OAuth keyring storage: https://developers.cloudflare.com/changelog/post/2026-06-03-wrangler-keyring-credential-storage/
- Cloudflare Access OTP: https://developers.cloudflare.com/cloudflare-one/integrations/identity-providers/one-time-pin/
- Access policies: https://developers.cloudflare.com/cloudflare-one/access-controls/policies/
