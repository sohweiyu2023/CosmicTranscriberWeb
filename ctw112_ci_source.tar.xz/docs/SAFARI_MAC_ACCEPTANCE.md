# Safari / Mac Final Acceptance Checklist

Run only after automated gates and staging pass.

1. Open the production URL in current Safari on macOS.
2. Authenticate through Cloudflare Access.
3. Configure a dedicated OpenAI API key.
4. Confirm model/language native dropdowns are readable, keyboard/touch selectable and last enabled item works.
5. Drag/drop or choose one short non-sensitive MP3.
6. Transcribe it.
7. Download TXT.
8. Download Markdown.
9. Test one short diarized recording; confirm speaker labels are sensible and part-scoped.
10. Toggle Cosmic Night/Paper, check normal and narrow window layouts, and optionally zoom to 200%.
11. Report Safari version, exact reproduction steps and scrubbed diagnostics for any issue.

Do not report this checklist as passed until a real Mac/Safari run has actually happened.
