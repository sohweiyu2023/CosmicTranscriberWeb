# Dependency and Licensing Notices

## Direct runtime dependencies
- `jose` `^6.2.8` — JOSE/JWT/JWK implementation used for Cloudflare Access assertion verification. MIT; verify installed metadata at release.
- `@noble/hashes` `^2.3.0` — incremental SHA-256 for browser-side streaming source/chunk fingerprints. MIT; verify installed metadata at release.

## Direct development/test dependencies
- `@cloudflare/vitest-pool-workers` `^0.20.3`
- `@playwright/test` `^1.62.1`
- `msw` `^2.15.0`
- `vitest` `^4.1.10`
- `wrangler` `^4.120.0`

These ranges were cross-checked against current public package/release metadata during the 2026-08-10 audit. The user's 1.0.5 Windows run actually refreshed these direct packages, completed install-script review/rebuild and reported zero npm-audit vulnerabilities, but certification later stopped at whole-Worker integration. Therefore that temporary 1.0.5 lock is useful runtime evidence but is **not** a certified 1.0.12 lock. The audit sandbox does not fabricate the exact transitive graph; 1.0.12 certification must regenerate it through the public registry and retest it.

## Release policy
`package.json` contains compatible ranges; `package-lock.json` must contain the exact graph actually tested. Release certification uses the private exact Node 24.19.0 + npm 12.0.2 Windows toolchain and is blocked until a public-registry lock passes `npm run deps:lock:verify`, `strict-allow-scripts=true` plus the reviewed install-script policy, clean `npm ci`, `npm audit`, `npm ls --all`, license review and the full validation suite. Runtime code uses no third-party CDN assets.

Use:
- `npm run deps:check` — show outdated direct/transitive packages.
- `npm run deps:update` — compatible updates, reinstall Playwright browsers, audit and full validation.
- `npm run deps:latest` — deliberately query/update all direct dependencies to current `@latest`, then reinstall browsers, audit and full validation.
- `npm run deps:verify` — direct tree, audit, Playwright/Wrangler versions and full validation.

Official/public metadata reviewed 2026-08-10: current npm/GitHub/vendor package metadata. Node 24.x is the LTS line selected for this release; the official Node 24 archive listed v24.19.0 as the latest LTS build at review time. Re-run the commands above at every release.
