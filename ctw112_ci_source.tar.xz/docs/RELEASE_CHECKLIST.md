# Release Checklist — Cosmic Transcriber Web 1.0.12

A checked box means only the stated evidence exists. Never promote an audit-candidate ZIP by editing `RELEASE_MANIFEST.json`.

## Source / research / adversarial audit
- [x] Latest 1.0.10 Windows attempt reviewed: PowerShell parser/named-parameter preflight passed; portable Node 24.19.0 and private npm 12.0.2 bootstrap succeeded, but PowerShell resolved Node's bundled npm 11.17.0 `npm.ps1`; the runner stopped safely before dependency or deployment stages.
- [x] Machine-wide Node mutation removed from the release path; private official-hash-pinned Node 24.19.0 + npm 12.0.2 toolchain added and regression-tested.
- [x] Current OpenAI completed-file transcription/diarization/pricing behavior rechecked against official documentation on 2026-08-10.
- [x] Current Cloudflare Workers/Access/testing/keyring assumptions rechecked against official documentation on 2026-08-10.
- [x] Current Node 24 LTS / npm 12 / Playwright release assumptions reviewed.
- [x] Fresh whole-system source/security/release-tooling re-review completed.

## Dependency-free gates actually run on final 1.0.12
- [x] Version consistency: PASS.
- [x] JavaScript syntax/type-shape: **76 files**.
- [x] Local ES-module linkage: **23 modules**.
- [x] Static/security/release safeguards: **167/167**.
- [x] Secret scan: PASS.
- [x] Node/ffprobe functional suite: **88/88**.
- [x] Mutation suite: **224/224**.

## Latest user-supplied Windows evidence — 1.0.10

- [x] Paste-once ZIP discovery/extraction and shipped PowerShell preflight reached successfully.
- [x] Parser + named-parameter preflight PASS.
- [x] Reviewed portable Node 24.19.0 downloaded/extracted and passed the pinned hash/layout/version checks.
- [x] Exact private npm 12.0.2 installation completed and was directly verified in its private prefix.
- [x] Bare PowerShell `npm` then resolved Node's bundled npm 11.17.0 `npm.ps1`; certification stopped safely before dependency execution.
- [x] No 1.0.10 dependency, Worker, integration, browser or deployment result is claimed after that stop.
- [x] 1.0.12 binds PowerShell `npm` to the exact private `node.exe + npm-cli.js` pair while keeping global Node/npm untouched.

## Final 1.0.12 Windows release-certification gate
Run only from the extracted project root:

```powershell
pwsh -NoProfile -ExecutionPolicy Bypass -File .\FIRST-DEPLOY-WINDOWS.ps1
```

The script must prove all of the following:
- [ ] PowerShell parser + named-parameter preflight PASS, including validator self-test.
- [ ] Cross-file version-consistency gate PASS.
- [ ] Private toolchain activates exact Node 24.19.0 + npm 12.0.2, and public npm registry is selected.
- [ ] Current direct dependencies refreshed; portable `package-lock.json` generated.
- [ ] `npm outdated` reports no direct updates.
- [ ] strict install-script/npmrc policy PASS; rebuild only after lock review.
- [ ] `npm audit` PASS/reviewed.
- [ ] clean `npm ci` PASS.
- [ ] Worker runtime tests PASS.
- [ ] whole-Worker integration PASS **all tests** (currently 9 scenarios).
- [ ] Chromium/Firefox/WebKit/Mobile Safari-emulation E2E PASS.
- [ ] installed Chrome/Edge E2E PASS on Windows.
- [ ] built-frontend inspection PASS.
- [ ] secret scan PASS.
- [ ] isolated release packaging PASS.
- [ ] generated ZIP root exactly `CosmicTranscriberWeb-1.0.12/`.
- [ ] fresh ZIP extraction + checksum/Unicode/secret verification PASS.
- [ ] fresh extraction `npm ci` + complete release verification PASS again.
- [ ] ZIP internal `RELEASE_MANIFEST.json` says `releaseReady:true`.
- [ ] final release ZIP SHA-256 recorded.

## Staging — only from the pristine deployment folder prepared by successful certification
- [ ] Use `npm run configure:access:staging` to fill only staging `ACCESS_TEAM_DOMAIN` and `ACCESS_AUDIENCE`; do not hand-edit unrelated fields.
- [ ] No extra source file added; no source/signed config changed beyond those permitted Access values.
- [ ] `node scripts/deploy-verify.mjs staging` PASS.
- [ ] Confirm Cosmic rate-limit namespace IDs do not collide with another Worker in the account.
- [ ] Wrangler login uses `--use-keyring`; `whoami` confirms Windows Credential Manager-backed credentials and the account containing `awakeningtoreality.com`.
- [ ] `npm run deploy:first:staging` rebuilds + inspects assets, generates a staging-only secret, and deploys with `--strict`.
- [ ] `transcriber-staging.awakeningtoreality.com` Custom Domain/TLS works.
- [ ] workers.dev disabled; Preview URLs disabled.
- [ ] Cloudflare Access OTP allowed tester passes; unauthorized email fails.
- [ ] BYOK plaintext absent from JS-readable storage/cookies/URLs/network echoes.
- [ ] Optional tiny live OpenAI test only after mock/staging checks and explicit acceptance of its charge.
- [ ] Cloudflare resource/observability behavior reviewed.

## Production — only after staging acceptance
- [ ] Create separate Cosmic production Access application for `transcriber.awakeningtoreality.com`; do not alter CiteLedger/global IdPs.
- [ ] Use `npm run configure:access:production` to fill only production `ACCESS_TEAM_DOMAIN` and production AUD.
- [ ] `node scripts/deploy-verify.mjs production` PASS.
- [ ] `npm run deploy:first:production` uses a **different** generated production BYOK master key and rebuilds/inspects before deploy.
- [ ] production Custom Domain/TLS/Access/exposure/BYOK smoke checks PASS.
- [ ] known-good deployment ID recorded and rollback procedure understood.

## Final platform gate
- [ ] Real macOS Safari manual acceptance PASS. **Playwright WebKit is not branded Safari certification.**
