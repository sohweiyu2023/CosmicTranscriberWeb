# Testing Guide — Cosmic Transcriber Web 1.0.12

## Evidence discipline

Never call a gate PASS unless the command actually ran successfully on the named artifact. The final dependency-free 1.0.12 audit source actually executed **76 syntax/type-shape files, 23 ES-module links, 167 static/security/release safeguards, secret scan, 88/88 Node/ffprobe functional tests and 224/224 mutation tests** successfully.

The latest user Windows evidence is the 1.0.10 attempt. Its paste-once launcher and PowerShell parser/named-parameter preflight passed; portable Node 24.19.0 and private npm 12.0.2 bootstrap succeeded, but bare PowerShell `npm` resolved Node's bundled npm 11.17.0 `npm.ps1`. 1.0.12 binds PowerShell `npm` to the exact verified private `node.exe + npm-cli.js` pair and keeps the private prefix first for child package scripts. The prior 1.0.5 run remains the last dependency-backed integration evidence (8/9 before the harness repair). See `AUTOMATED_TEST_RESULTS.md`.

## Windows first release — preferred one-command path

From the extracted audit-candidate project root in PowerShell 7 run:

```powershell
pwsh -NoProfile -ExecutionPolicy Bypass -File .\FIRST-DEPLOY-WINDOWS.ps1
```

This is intentionally a **real script process**, not a long interactive paste. It activates the private reviewed Node/npm toolchain, calls the certification-only `RELEASE-WINDOWS.ps1`, and does not enter Access/Cloudflare deployment stages unless that child process really exits 0. A failure exits the guided script 1 and prints `STOPPED — DO NOT CONTINUE TO A LATER STAGE`.

The script first validates the PowerShell deployment/toolchain scripts, activates the private exact Node 24.19.0/npm 12.0.2 toolchain and enforces public-registry/strict install-script prerequisites, then performs scripts-disabled dependency resolution, lock-wide install-script review/rebuild, clean `npm ci`, browser installation and `npm run package:source`. Normal package creation itself runs complete release verification before ZIP creation and again after fresh extraction. On success the PowerShell script also extracts the certified ZIP into a fresh `deploy\CosmicTranscriberWeb-1.0.12` directory and prints its exact path, so you should not invent or pre-create the deployment path.

## Individual gates for debugging only

If the one-command runner fails and you need to isolate the failing layer:

```powershell
npm run validate
npm run test:worker
npm run test:integration
npm run test:e2e:core
npm run test:e2e:branded
npm run build:inspect
npm run audit:secrets
npm run release:verify
```

`test:integration` builds first and uses Cloudflare `createTestHarness()` against the Wrangler production build/config. The suite starts the harness, resets it between tests, closes it after tests, uses signed test Access JWTs and an MSW JWKS/OpenAI network layer with unhandled requests rejected. The 1.0.12 suite currently includes 9 scenarios, including static-shell Access, bad/spoofed Access, cross-origin key creation, strict key JSON, BYOK session creation, server-owned Authorization, model rejection and redirect blocking.

`test:e2e:core` covers Chromium, Firefox, WebKit and Mobile Safari emulation. `test:e2e:branded` covers installed Chrome and Edge on Windows. The local web server uses a randomized port and authenticated health probe with no existing-server reuse.

## Dependency maintenance

`npm run deps:latest` deliberately upgrades all direct dependencies to registry `@latest` with lifecycle scripts disabled, verifies the resulting lock-wide install-script policy, runs `npm rebuild` only after that review passes, then installs the **installed project's** Playwright core browsers, audits npm and runs the full non-branded validation path. It does not use interactive `npx playwright` package download.

Release certification additionally checks `npm outdated`; a stale but passing direct dependency graph is not certifiable.

The reviewed npm install-script policy uses exact-version positive approvals and explicit denial for the known optional macOS `fsevents` lock-metadata anomaly. Release certification requires npm 12. `.npmrc` sets `strict-allow-scripts=true`, so an unreviewed dependency install script is a hard install error instead of npm 12's default blocked-with-warning behavior; `strict-npmrc=true` also makes unknown project npm configuration fatal.

## Package round trip

A release ZIP is built in an isolated staging tree; the editable tree remains `releaseReady:false`. Verification requires:

- canonical ZIP root `CosmicTranscriberWeb-1.0.12/`;
- UTF-8 filename flag for every entry;
- exact `tests/fixtures/ID3 Unicode 東京.mp3`;
- CRC and SHA-256 verification;
- no node_modules/dist/test artifacts/secrets;
- fresh-extraction secret scan and dependency-free validation;
- portable lock + `npm ci` for release mode;
- complete dependency-backed release verification again after extraction.

If any release round-trip step fails, the failed release ZIP is deleted.

## Deployment is also a test boundary

A deployable tree must have `releaseReady:true`, exact certified source-file membership and matching checksums. Only four private Access team/AUD Wrangler fields may differ from certification. Extra source files fail provenance. Each deploy rebuilds and inspects `dist/public` immediately before Wrangler and uses `--strict`.

## Safari statement

Playwright WebKit is valuable automated engine coverage but is not branded Safari. A short real macOS Safari acceptance remains a separate final gate.
