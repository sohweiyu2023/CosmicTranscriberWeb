# Real Mac Tester Handoff

The tester needs only the production URL, an allowed Cloudflare Access identity, their own dedicated OpenAI API key, and two short non-sensitive MP3s (one single-speaker/general, one multi-speaker). Do not send the source package or any owner credential merely to perform Safari acceptance. Use the eleven-step checklist in `SAFARI_MAC_ACCEPTANCE.md` and return only scrubbed issue details/screenshots.
