import { authenticateAccess } from "./access.js";
import { clearCredentialCookie, createCredentialSession, readCredentialSession } from "./byok.js";
import { COOKIE_NAME, MODEL_ALLOWLIST_REVISION, MODELS, PRICING_LAST_VERIFIED } from "./config.js";
import { ApiError, errorToSafeJson } from "./errors.js";
import { dispatchTranscription, safeOperationalLog } from "./openai.js";
import { rateLimit } from "./rate-limit.js";
import { getKeyTestMp3 } from "./test-audio.js";
import { jsonResponse, randomId, sha256Base64Url } from "./utils.js";
import { decodeMetadataHeader, readSmallJson, validateApiKey, validateAudioRequestHeaders, validateOrigin, validateTranscriptionMetadata } from "./validation.js";


const STATIC_SECURITY_HEADERS = Object.freeze({
  "Cache-Control": "no-store, max-age=0",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), bluetooth=(), browsing-topics=(), interest-cohort=()",
  "Cross-Origin-Opener-Policy": "same-origin",
  "Cross-Origin-Resource-Policy": "same-origin"
});
function staticCsp(isHttps) {
  return `default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'; manifest-src 'none'; media-src 'self' blob:; worker-src 'none'${isHttps ? '; upgrade-insecure-requests' : ''}`;
}
async function authenticatedAssetResponse(request, env) {
  if (!env.ASSETS?.fetch) throw new ApiError(500, "assets_binding_missing", "Static assets are not configured.");
  const response = await env.ASSETS.fetch(request);
  const headers = new Headers(response.headers);
  for (const [name, value] of Object.entries(STATIC_SECURITY_HEADERS)) headers.set(name, value);
  const isHttps = new URL(request.url).protocol === "https:";
  headers.set("Content-Security-Policy", staticCsp(isHttps));
  if (isHttps) headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains"); else headers.delete("Strict-Transport-Security");
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

function setCookieHeader(response, value) {
  if (!value) return response;
  const headers = new Headers(response.headers); headers.append("Set-Cookie", value);
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

async function principalHash(sub, env) { const origin=new URL(env.APP_ORIGIN).origin; return (await sha256Base64Url(`ctw-user|${origin}|${sub}`)).slice(0, 16); }
async function checkpointPrincipalScope(principal, env) {
  const origin = new URL(env.APP_ORIGIN).origin;
  return (await sha256Base64Url(`ctw-checkpoint-scope|${origin}|${principal.sub}`)).slice(0, 32);
}

function method(request, expected) {
  if (request.method !== expected) throw new ApiError(405, "method_not_allowed", `Use ${expected} for this route.`);
}

async function statusRoute(request, env, principal) {
  method(request, "GET");
  const principalScope = await checkpointPrincipalScope(principal, env);
  try {
    const session = await readCredentialSession(request, principal, env, { renew: true });
    return setCookieHeader(jsonResponse({ ok: true, configured: true, expiresAt: session.expiresAt, absoluteExpiresAt: session.absoluteExpiresAt, principalScope, version: env.APP_VERSION, modelAllowlistRevision: MODEL_ALLOWLIST_REVISION, pricingLastVerified: PRICING_LAST_VERIFIED }), session.renewal);
  } catch (e) {
    if (e instanceof ApiError && (e.code === "key_session_invalid" || e.code === "key_session_expired")) {
      return setCookieHeader(jsonResponse({ ok: true, configured: false, principalScope, version: env.APP_VERSION, modelAllowlistRevision: MODEL_ALLOWLIST_REVISION, pricingLastVerified: PRICING_LAST_VERIFIED }), clearCredentialCookie());
    }
    throw e;
  }
}

async function createKeyRoute(request, env, principal) {
  method(request, "POST"); validateOrigin(request, env); await rateLimit(env, "RL_KEY_SESSION", principal, "key-session");
  const body = await readSmallJson(request, 2048);
  for (const key of Object.keys(body)) if (key !== "apiKey") throw new ApiError(400, "invalid_json", "Request contains an unsupported field.");
  const key = validateApiKey(body.apiKey);
  const created = await createCredentialSession(key, principal, env);
  return setCookieHeader(jsonResponse({ ok: true, configured: true, expiresAt: created.expiresAt, absoluteExpiresAt: created.absoluteExpiresAt }), created.setCookie);
}

async function forgetKeyRoute(request, env, principal) {
  method(request, "DELETE"); validateOrigin(request, env); await rateLimit(env, "RL_KEY_SESSION", principal, "key-forget");
  return setCookieHeader(jsonResponse({ ok: true, configured: false, note: "This browser cookie was cleared. If key compromise is suspected, revoke or rotate the OpenAI key at OpenAI." }), clearCredentialCookie());
}

async function testKeyRoute(request, env, principal) {
  method(request, "POST"); validateOrigin(request, env); await rateLimit(env, "RL_KEY_TEST", principal, "key-test");
  const body = await readSmallJson(request, 2048);
  for (const key of Object.keys(body)) if (key !== "confirmMinimalUsage") throw new ApiError(400, "invalid_json", "Request contains an unsupported field.");
  if (body.confirmMinimalUsage !== true) throw new ApiError(400, "confirmation_required", "Confirm that the tiny transcription-permission test may incur minimal OpenAI API usage.");
  const session = await readCredentialSession(request, principal, env, { renew: true });
  const audio = getKeyTestMp3();
  const metadata = validateTranscriptionMetadata({
    v: 1, jobId: randomId("keytest-job"), fileId: randomId("keytest-file"), chunkIndex: 1, chunkCount: 1,
    attemptId: randomId("keytest-attempt"), declaredBytes: audio.byteLength, durationSeconds: 0.25, model: "gpt-transcribe",
    languages: [], keywords: [], prompt: "", requestKind: "key-test"
  });
  const result = await dispatchTranscription({ requestBody: new Blob([audio], { type: "audio/mpeg" }).stream(), metadata, apiKey: session.apiKey });
  const response = jsonResponse({ ok: true, permitted: true, diagnostics: result.diagnostics });
  return setCookieHeader(response, session.renewal);
}

async function transcribeRoute(request, env, principal, requestId) {
  method(request, "POST"); validateOrigin(request, env); await rateLimit(env, "RL_TRANSCRIBE", principal, "transcribe");
  const metadata = decodeMetadataHeader(request);
  if (metadata.requestKind !== "transcription") throw new ApiError(400, "invalid_metadata", "This route accepts transcription requests only.");
  validateAudioRequestHeaders(request, metadata.declaredBytes);
  const session = await readCredentialSession(request, principal, env, { renew: true });
  const user = await principalHash(principal.sub, env);
  const started = Date.now();
  try {
    const result = await dispatchTranscription({ requestBody: request.body, metadata, apiKey: session.apiKey, signal: request.signal });
    safeOperationalLog({ route: "/api/transcribe", requestId, user, jobId: metadata.jobId, chunkIndex: metadata.chunkIndex, status: 200, category: "success", openaiRequestId: result.diagnostics.openaiRequestId, elapsedMs: Date.now() - started });
    return setCookieHeader(jsonResponse({ ok: true, result: result.result, diagnostics: { ...result.diagnostics, appRequestId: requestId } }), session.renewal);
  } catch (error) {
    const details = error instanceof ApiError ? error.details : undefined;
    safeOperationalLog({ route: "/api/transcribe", requestId, user, jobId: metadata.jobId, chunkIndex: metadata.chunkIndex, status: error?.status || 502, category: error?.code || "unknown", openaiRequestId: details?.openaiRequestId, elapsedMs: Date.now() - started });
    throw error;
  }
}

export default {
  async fetch(request, env) {
    const requestId = randomId("req");
    const url = new URL(request.url);
    try {
      const principal = await authenticateAccess(request, env);
      if (!url.pathname.startsWith("/api/")) return await authenticatedAssetResponse(request, env);
      if (url.pathname === "/api/session/status") return await statusRoute(request, env, principal);
      if (url.pathname === "/api/key/session") return await createKeyRoute(request, env, principal);
      if (url.pathname === "/api/key/forget") return await forgetKeyRoute(request, env, principal);
      if (url.pathname === "/api/key/test") return await testKeyRoute(request, env, principal);
      if (url.pathname === "/api/transcribe") return await transcribeRoute(request, env, principal, requestId);
      throw new ApiError(404, "route_not_found", "API route not found.");
    } catch (error) {
      const status = error instanceof ApiError ? error.status : 500;
      const response = jsonResponse(errorToSafeJson(error, requestId), status);
      if (error instanceof ApiError && ["key_session_invalid", "key_session_expired"].includes(error.code)) return setCookieHeader(response, clearCredentialCookie());
      return response;
    }
  }
};
