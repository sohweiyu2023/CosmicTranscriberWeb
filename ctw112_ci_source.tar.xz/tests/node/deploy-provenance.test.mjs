import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {validateReleaseManifest,verifyReleaseProvenance,wranglerReleaseFingerprint} from '../../scripts/deploy-provenance.mjs';
const h=x=>createHash('sha256').update(x).digest('hex');

function wrangler(aud='REPLACE_WITH_STAGING_ACCESS_AUD_TAG',team='https://YOUR_TEAM.cloudflareaccess.com'){
  return {workers_dev:false,preview_urls:false,env:{staging:{vars:{ACCESS_TEAM_DOMAIN:team,ACCESS_AUDIENCE:aud,APP_ORIGIN:'https://transcriber-staging.awakeningtoreality.com'}},production:{vars:{ACCESS_TEAM_DOMAIN:'https://YOUR_TEAM.cloudflareaccess.com',ACCESS_AUDIENCE:'REPLACE_WITH_PRODUCTION_ACCESS_AUD_TAG',APP_ORIGIN:'https://transcriber.awakeningtoreality.com'}}}};
}

test('deployment requires release certification and permits only private Access values to change in Wrangler',async()=>{
  const initialWrangler=wrangler();
  const fingerprint=wranglerReleaseFingerprint(initialWrangler);
  const validManifest={product:'Cosmic Transcriber Web',version:'1.0.6',releaseReady:true,dependencyLock:{status:'verified',sha256:'a'.repeat(64),registry:'https://registry.npmjs.org/'},wranglerReleaseFingerprint:fingerprint};
  assert.deepEqual(validateReleaseManifest(validManifest,'1.0.6'),[]);
  assert.match(validateReleaseManifest({...validManifest,releaseReady:false},'1.0.6').join(' '),/not release-certified/i);
  assert.match(validateReleaseManifest({...validManifest,dependencyLock:{status:'missing',sha256:null,registry:null}},'1.0.6').join(' '),/dependency lock is not verified/i);
  const dir=await mkdtemp(path.join(tmpdir(),'cosmic-provenance-'));
  try{
    const pkg='{"name":"cosmic","version":"1.0.6"}\n',src='immutable\n',wranglerText=JSON.stringify(initialWrangler,null,2)+'\n';
    const manifest=JSON.stringify(validManifest)+'\n';
    await Promise.all([writeFile(path.join(dir,'package.json'),pkg),writeFile(path.join(dir,'app.txt'),src),writeFile(path.join(dir,'wrangler.jsonc'),wranglerText),writeFile(path.join(dir,'RELEASE_MANIFEST.json'),manifest)]);
    const sums=[[manifest,'RELEASE_MANIFEST.json'],[pkg,'package.json'],[src,'app.txt'],[wranglerText,'wrangler.jsonc']].map(([v,n])=>`${h(v)}  ${n}`).join('\n')+'\n';
    await writeFile(path.join(dir,'SHA256SUMS.txt'),sums);
    assert.deepEqual(await verifyReleaseProvenance(dir,{packageVersion:'1.0.6'}),[]);

    const privateFilled=wrangler('staging-audience-123456','https://citeledger.cloudflareaccess.com');
    privateFilled.env.production.vars.ACCESS_AUDIENCE='production-audience-123456';
    privateFilled.env.production.vars.ACCESS_TEAM_DOMAIN='https://citeledger.cloudflareaccess.com';
    await writeFile(path.join(dir,'wrangler.jsonc'),JSON.stringify(privateFilled,null,2)+'\n');
    assert.deepEqual(await verifyReleaseProvenance(dir,{packageVersion:'1.0.6'}),[],'only the four private Access values may change after release packaging');

    privateFilled.workers_dev=true;
    await writeFile(path.join(dir,'wrangler.jsonc'),JSON.stringify(privateFilled,null,2)+'\n');
    assert.match((await verifyReleaseProvenance(dir,{packageVersion:'1.0.6'})).join(' '),/Wrangler security\/configuration fingerprint mismatch/i);

    privateFilled.workers_dev=false;
    await writeFile(path.join(dir,'wrangler.jsonc'),JSON.stringify(privateFilled,null,2)+'\n');
    await writeFile(path.join(dir,'app.txt'),'tampered\n');
    assert.match((await verifyReleaseProvenance(dir,{packageVersion:'1.0.6'})).join(' '),/checksum mismatch: app\.txt/);
    await writeFile(path.join(dir,'app.txt'),src);
    await writeFile(path.join(dir,'uncertified.js'),'console.log(\"not certified\")\n');
    assert.match((await verifyReleaseProvenance(dir,{packageVersion:'1.0.6'})).join(' '),/uncertified source file present: uncertified\.js/);
  }finally{await rm(dir,{recursive:true,force:true})}
});
