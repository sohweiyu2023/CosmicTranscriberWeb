import test from 'node:test';
import assert from 'node:assert/strict';
import {validateDeploymentConfig} from '../../scripts/deploy-verify.mjs';

function base(){return {
  workers_dev:false,preview_urls:false,
  observability:{enabled:true,logs:{enabled:true,invocation_logs:false,head_sampling_rate:0.1}},
  assets:{directory:'./dist/public',binding:'ASSETS',run_worker_first:true},
  secrets:{required:['BYOK_SESSION_MASTER_KEY_CURRENT']},
  env:{
    staging:{workers_dev:false,preview_urls:false,routes:[{pattern:'transcriber-staging.awakeningtoreality.com',custom_domain:true}],vars:{APP_VERSION:'1.0.6',DEPLOYMENT_ENV:'staging',APP_ORIGIN:'https://transcriber-staging.awakeningtoreality.com',ACCESS_TEAM_DOMAIN:'https://citeledger.cloudflareaccess.com',ACCESS_AUDIENCE:'staging-audience-123',LOCAL_AUTH_BYPASS:'false'},secrets:{required:['BYOK_SESSION_MASTER_KEY_CURRENT']},ratelimits:[{name:'RL_KEY_SESSION',namespace_id:'101',simple:{limit:8,period:60}},{name:'RL_KEY_TEST',namespace_id:'102',simple:{limit:5,period:60}},{name:'RL_TRANSCRIBE',namespace_id:'103',simple:{limit:30,period:60}}]},
    production:{workers_dev:false,preview_urls:false,routes:[{pattern:'transcriber.awakeningtoreality.com',custom_domain:true}],vars:{APP_VERSION:'1.0.6',DEPLOYMENT_ENV:'production',APP_ORIGIN:'https://transcriber.awakeningtoreality.com',ACCESS_TEAM_DOMAIN:'https://citeledger.cloudflareaccess.com',ACCESS_AUDIENCE:'production-audience-123',LOCAL_AUTH_BYPASS:'false'},secrets:{required:['BYOK_SESSION_MASTER_KEY_CURRENT']},ratelimits:[{name:'RL_KEY_SESSION',namespace_id:'201',simple:{limit:8,period:60}},{name:'RL_KEY_TEST',namespace_id:'202',simple:{limit:5,period:60}},{name:'RL_TRANSCRIBE',namespace_id:'203',simple:{limit:30,period:60}}]}
  }
}}

test('deployment verifier accepts a locked worker-first Access configuration',()=>{assert.deepEqual(validateDeploymentConfig(base(),'staging',{packageVersion:'1.0.6'}),[])});
test('deployment verifier blocks worker-first exposure, auth bypass, route drift and namespace collisions',()=>{const c=base();c.assets.run_worker_first=['/api/*'];c.env.staging.vars.LOCAL_AUTH_BYPASS='true';c.env.staging.routes[0].pattern='wrong.example.com';c.env.production.ratelimits[0].namespace_id='101';const errors=validateDeploymentConfig(c,'staging',{packageVersion:'1.0.6'}).join('|');assert.match(errors,/run Worker first/);assert.match(errors,/LOCAL_AUTH_BYPASS/);assert.match(errors,/placeholder|route and APP_ORIGIN/);assert.match(errors,/staging and production rate-limit namespace IDs/)});
test('deployment verifier rejects malformed Access team origins and version drift',()=>{const c=base();c.env.production.vars.ACCESS_TEAM_DOMAIN='https://user:pass@citeledger.cloudflareaccess.com:443/path';c.env.production.vars.APP_VERSION='1.0.1';const errors=validateDeploymentConfig(c,'production',{packageVersion:'1.0.6'}).join('|');assert.match(errors,/ACCESS_TEAM_DOMAIN/);assert.match(errors,/APP_VERSION/)});

test('deployment verifier keeps only sampled redacted custom logs and disables automatic invocation logs',()=>{const c=base();c.observability.logs.invocation_logs=true;c.observability.logs.head_sampling_rate=1;const errors=validateDeploymentConfig(c,'staging',{packageVersion:'1.0.6'}).join('|');assert.match(errors,/invocation logs must be disabled/);assert.match(errors,/sampling/)});
