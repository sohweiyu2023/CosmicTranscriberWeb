import {beforeAll,beforeEach,afterAll,afterEach,describe,it,expect} from 'vitest';
import {http,HttpResponse} from 'msw';
import {setupServer} from 'msw/node';
import {createTestHarness} from 'wrangler';
import {SignJWT,generateKeyPair,exportJWK} from 'jose';

const network=setupServer();
const TEST_BYOK_MASTER_KEY='AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA';
const issuer='https://test.cloudflareaccess.com';
const audience='test-aud';
let server,worker,privateKey,jwk;
const origin='http://localhost';

beforeAll(async()=>{
  network.listen({onUnhandledRequest:'error'});
  const pair=await generateKeyPair('RS256');
  privateKey=pair.privateKey;
  jwk={...(await exportJWK(pair.publicKey)),kid:'test-key',alg:'RS256',use:'sig'};
  server=createTestHarness({workers:[{
    configPath:'./tests/integration/wrangler.test.jsonc',
    secrets:{BYOK_SESSION_MASTER_KEY_CURRENT:TEST_BYOK_MASTER_KEY}
  }]});
  await server.listen();
  worker=server.getWorker();
});
beforeEach(()=>{
  network.use(http.get(`${issuer}/cdn-cgi/access/certs`,()=>HttpResponse.json({keys:[jwk]})));
});
afterEach(async()=>{
  network.resetHandlers();
  await server.reset();
  worker=server.getWorker();
});
afterAll(async()=>{
  network.close();
  await server?.close();
});

async function accessToken(overrides={}){
  return new SignJWT({type:'app',sub:'integration-user',...overrides})
    .setProtectedHeader({alg:'RS256',kid:'test-key'})
    .setIssuer(issuer).setAudience(audience).setIssuedAt().setExpirationTime('5m').sign(privateKey);
}
async function authHeaders(extra={}){return {'Cf-Access-Jwt-Assertion':await accessToken(),...extra}}
async function createSession(key='test-key'){
  const r=await worker.fetch(`${origin}/api/key/session`,{method:'POST',headers:await authHeaders({Origin:origin,'Content-Type':'application/json'}),body:JSON.stringify({apiKey:key})});
  expect(r.status).toBe(200);
  return (r.headers.get('set-cookie')||'').split(';',1)[0];
}
function metadata(overrides={}){
  return {v:1,jobId:'job-1',fileId:'file-1',chunkIndex:1,chunkCount:1,attemptId:'attempt-1',declaredBytes:4,durationSeconds:1,model:'gpt-transcribe',languages:[],keywords:[],prompt:'',requestKind:'transcription',...overrides};
}
function encodeMeta(value){return Buffer.from(JSON.stringify(value)).toString('base64url')}
async function transcribe(cookie,meta=metadata(),headers={}){
  return worker.fetch(`${origin}/api/transcribe`,{method:'POST',headers:await authHeaders({Origin:origin,'Content-Type':'audio/mpeg','X-Cosmic-Metadata':encodeMeta(meta),Cookie:cookie,...headers}),body:new Uint8Array([1,2,3,4])});
}

describe('whole-Worker integration against real Wrangler entry/config',()=>{
  it('requires Access before serving static app assets and attaches security headers',async()=>{
    const missing=await worker.fetch(`${origin}/`);
    expect(missing.status).toBe(401);
    const valid=await worker.fetch(`${origin}/`,{headers:await authHeaders()});
    expect(valid.status).toBe(200);
    const html=await valid.text();
    expect(html).toContain('COSMIC TRANSCRIBER');
    expect(valid.headers.get('content-security-policy')).toContain("default-src 'self'");
    expect(valid.headers.get('x-frame-options')).toBe('DENY');
    expect(valid.headers.get('cache-control')).toContain('no-store');
  });

  it('requires a cryptographically valid Access JWT and ignores spoofable email header',async()=>{
    const missing=await worker.fetch(`${origin}/api/session/status`,{headers:{'Cf-Access-Authenticated-User-Email':'victim@example.test'}});
    expect(missing.status).toBe(401);
    const wrongAud=await new SignJWT({type:'app',sub:'integration-user'}).setProtectedHeader({alg:'RS256',kid:'test-key'}).setIssuer(issuer).setAudience('wrong-aud').setIssuedAt().setExpirationTime('5m').sign(privateKey);
    const invalid=await worker.fetch(`${origin}/api/session/status`,{headers:{'Cf-Access-Jwt-Assertion':wrongAud}});
    expect(invalid.status).toBe(401);
    const valid=await worker.fetch(`${origin}/api/session/status`,{headers:await authHeaders()});
    expect(valid.status).toBe(200);
    const validBody=await valid.json();
    expect(validBody.principalScope).toMatch(/^[A-Za-z0-9_-]{32}$/);
    const other=await worker.fetch(`${origin}/api/session/status`,{headers:{'Cf-Access-Jwt-Assertion':await accessToken({sub:'integration-user-2'})}});
    expect(other.status).toBe(200);
    expect((await other.json()).principalScope).not.toBe(validBody.principalScope);
  });

  it('rejects cross-origin credential setup before any upstream OpenAI request',async()=>{
    const r=await worker.fetch(`${origin}/api/key/session`,{method:'POST',headers:await authHeaders({Origin:'https://evil.test','Content-Type':'application/json'}),body:JSON.stringify({apiKey:'test-prefixless-key'})});
    expect(r.status).toBe(403);
  });

  it('does not reflect arbitrary credential-route field names in errors',async()=>{
    const sentinel='PRIVATE-SENTINEL-FIELD';
    const r=await worker.fetch(`${origin}/api/key/session`,{method:'POST',headers:await authHeaders({Origin:origin,'Content-Type':'application/json'}),body:JSON.stringify({apiKey:'test-key',[sentinel]:1})});
    const text=await r.text();
    expect(r.status).toBe(400);
    expect(text).not.toContain(sentinel);
  });

  it('rejects unknown key-test JSON fields before any OpenAI request',async()=>{
    const cookie=await createSession();
    const sentinel='PRIVATE-KEYTEST-FIELD';
    const r=await worker.fetch(`${origin}/api/key/test`,{method:'POST',headers:await authHeaders({Origin:origin,'Content-Type':'application/json',Cookie:cookie}),body:JSON.stringify({confirmMinimalUsage:true,[sentinel]:1})});
    const text=await r.text();
    expect(r.status).toBe(400);
    expect(text).not.toContain(sentinel);
  });

  it('creates BYOK session without echoing plaintext key',async()=>{
    const key='SEED-NO-PERSIST-KEY-7d9b4676';
    const r=await worker.fetch(`${origin}/api/key/session`,{method:'POST',headers:await authHeaders({Origin:origin,'Content-Type':'application/json'}),body:JSON.stringify({apiKey:key})});
    const text=await r.text();
    expect(r.status).toBe(200);
    expect(text).not.toContain(key);
    const set=r.headers.get('set-cookie')||'';
    expect(set).toContain('__Host-cosmic_byok=');
    expect(set).toContain('HttpOnly');
    expect(set).toContain('Secure');
    expect(set).toContain('SameSite=Strict');
    expect(set).not.toContain('Domain=');
  });

  it('constructs upstream Authorization from BYOK and ignores browser Authorization',async()=>{
    let seenAuth='',seenContentType='',seenModel='',seenFileSize=-1,handlerError=null,mockHits=0;
    network.use(http.post('https://api.openai.com/v1/audio/transcriptions',async({request})=>{
      mockHits++;
      seenAuth=request.headers.get('authorization')||'';
      seenContentType=request.headers.get('content-type')||'';
      try {
        // MSW documents the intercepted object as a standard Request and
        // recommends cloning before reading its body. Keep assertions OUT of
        // the resolver: an assertion thrown here becomes a synthetic network
        // failure and the Worker correctly classifies that as billing-ambiguous,
        // which would hide the real test failure behind a misleading HTTP 502.
        const form=await request.clone().formData();
        seenModel=String(form.get('model')||'');
        const file=form.get('file');
        seenFileSize=file&&typeof file==='object'&&Number.isFinite(file.size)?file.size:-1;
      } catch (error) {
        handlerError=error;
      }
      return HttpResponse.json({text:'ok'},{headers:{'x-request-id':'req_mock_auth'}});
    }));
    const cookie=await createSession('server-side-byok-key');
    const r=await transcribe(cookie,metadata(),{Authorization:'Bearer attacker-browser-token'});
    const responseText=await r.clone().text();
    expect(mockHits,'OpenAI MSW mock must be reached exactly once').toBe(1);
    expect(r.status,responseText).toBe(200);
    expect(handlerError).toBeNull();
    expect(seenAuth).toBe('Bearer server-side-byok-key');
    expect(seenContentType).toMatch(/^multipart\/form-data;\s*boundary=/i);
    expect(seenModel).toBe('gpt-transcribe');
    expect(seenFileSize).toBe(4);
  });

  it('rejects unsupported/realtime model before upstream',async()=>{
    const cookie=await createSession();
    const r=await transcribe(cookie,metadata({model:'gpt-realtime'}));
    expect(r.status).toBe(400);
  });

  it('never follows unexpected OpenAI redirect',async()=>{
    let redirectMockHits=0;
    network.use(http.post('https://api.openai.com/v1/audio/transcriptions',()=>{redirectMockHits++;return HttpResponse.redirect('https://evil.invalid/',302)}));
    const key='test-key';
    const cookie=await createSession(key);
    const r=await transcribe(cookie);
    expect(redirectMockHits,'redirect MSW mock must be reached exactly once').toBe(1);
    expect(r.status).toBeGreaterThanOrEqual(500);
    expect(await r.text()).not.toContain(key);
  });
});
